function black_bg() {
  $("body").children().css("background-color","black"); 
}