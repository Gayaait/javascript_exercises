function red_border() {
  $("body").children().css("border","1px solid red"); 
}