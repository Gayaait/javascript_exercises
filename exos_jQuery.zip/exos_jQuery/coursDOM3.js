$(document).ready(function(){
    $("li").parents().css("border","1px solid black");

    $("ul").parents("div").css("background-color", "lightBlue");
});